package com.thurpe.KafkaReportApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaReportAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaReportAppApplication.class, args);
	}

}
