package com.thurpe.KafkaReportApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaReportAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
